# ForexPulse Bot — Setup Guide

## Step 1 — Get your Telegram Bot Token

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Choose a name: e.g. `ForexPulse Bot`
4. Choose a username: e.g. `forexpulse_bot` (must end in `bot`)
5. BotFather replies with your **token** — looks like:
   `7123456789:AAFxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
6. Copy and save it — you'll need it below.

## Step 2 — Create your Telegram Channel (optional but recommended)

1. In Telegram, tap the pencil/compose icon → New Channel
2. Name it e.g. `ForexPulse Alerts`
3. Set it to Public, give it a username e.g. `@ForexPulseAlerts`
4. Add your bot as an **administrator** with "Post messages" permission

## Step 3 — Twitter/X API (optional)

If you want Twitter monitoring:
1. Go to https://developer.twitter.com
2. Create a project and app (free tier works)
3. Copy your **Bearer Token**

## Step 4 — Install & run

### On your computer or VPS:

```bash
# Clone or copy the bot files to a folder
cd forexpulse_bot

# Create virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export TELEGRAM_BOT_TOKEN="YOUR_BOT_TOKEN_HERE"
export TELEGRAM_CHANNEL_ID="@YourChannelUsername"
export TWITTER_BEARER_TOKEN="YOUR_TWITTER_BEARER_TOKEN"   # optional

# Run the bot
python bot.py
```

### Using a .env file (recommended):

Create a file called `.env` in the same folder:
```
TELEGRAM_BOT_TOKEN=7123456789:AAFxxxxxxxxxxxxxxxxxxxxxxx
TELEGRAM_CHANNEL_ID=@ForexPulseAlerts
TWITTER_BEARER_TOKEN=AAAA...   # leave blank if not using Twitter
```

Then install `python-dotenv` and add at the top of `bot.py`:
```python
from dotenv import load_dotenv
load_dotenv()
```

## Step 5 — Keep it running 24/7

### On a Linux VPS (Ubuntu/Debian):

Create a systemd service:

```bash
sudo nano /etc/systemd/system/forexpulse.service
```

Paste:
```ini
[Unit]
Description=ForexPulse Telegram Bot
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/forexpulse_bot
Environment=TELEGRAM_BOT_TOKEN=YOUR_TOKEN
Environment=TELEGRAM_CHANNEL_ID=@YourChannel
ExecStart=/home/ubuntu/forexpulse_bot/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl daemon-reload
sudo systemctl enable forexpulse
sudo systemctl start forexpulse
sudo systemctl status forexpulse   # check it's running
```

### Free cloud options:
- **Railway.app** — free tier, deploy via GitHub
- **Render.com** — free background workers
- **Fly.io** — free small VMs

## Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Subscribe to alerts |
| `/stop` | Unsubscribe |
| `/today` | Show today's economic calendar |
| `/news` | Show latest breaking news |
| `/help` | Show help |

## Customization in bot.py

| Setting | Default | Description |
|---------|---------|-------------|
| `PRE_EVENT_MINUTES` | 30 | Minutes before event to send reminder |
| `IMPACT_FILTER` | `["High"]` | Which impact levels to track |
| `CHECK_CALENDAR_EVERY` | 300 sec | How often to poll Forex Factory |
| `CHECK_NEWS_EVERY` | 120 sec | How often to poll news RSS feeds |
| `TWITTER_ACCOUNTS` | list of accounts | Accounts to monitor |
| `TWITTER_KEYWORDS` | list of keywords | Keywords to filter tweets |

## Troubleshooting

- **Bot not responding**: Check your token is correct
- **No Forex Factory data**: They may block scraping — try adding delays or rotating user agents
- **Twitter 401 error**: Bearer token is wrong or expired
- **Messages not posting to channel**: Make sure your bot is an admin in the channel
